﻿=== 微信打赏（Wechat Reward） ===
Contributors: tanteng
Donate link: http://www.tantengvip.com
Tags: donate, wechat, post
Requires at least: 3.0.1
Tested up to: 4.3.1
Stable tag: 1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

这是一款微信打赏插件，在文章末尾添加微信打赏功能，如果读者觉得这篇文章对他有用，可以用微信扫一扫打赏赞助。

This is a plugin for Wechat pay. If you think this is helpful for you, you can donate to author by wechat pay.
Wechat is the most popular IM APP in China, it has more than 700 million users in China.

Language: Chinese

== Installation ==

1. Upload `wechat-reward` to the `/wp-content/plugins/` directory 上传wechat-reward文件夹到'/wp-content/plugins/'目录
2. Activate the plugin through the 'Plugins' menu in WordPress 在WordPress后台激活插件，到设置页面进行设置

== Frequently Asked Questions ==

= 有后台设置更换二维码图片吗？ =

有


== Screenshots ==

1. 文章内容页
2. 后台管理设置页


== Changelog ==
= 1.6 =
* 稳定版

= 1.5 =
* 代码优化

= 1.4 =
* 新增微信打赏小挂件功能

= 1.3 =
* 优化代码结构和性能

= 1.2 =
* 修改css，保证打赏图标处于最上层，不被其他元素遮挡。（如代码高亮）

= 1.1 =
* 修改数组定义方式，兼容低版本的PHP

= 1.0 =
* 文章页底部显示打赏图标，鼠标移上去显示设置的微信收款二维码
* 后台管理页面可以更换自己的微信收款二维码

== 说明 ==

本插件只在文章页和非手机访问有效.

如果无法查看截图，请<a href="http://www.tantengvip.com/2015/11/wechat-rewrd-wordpress-plugin/" target="_blank">点击此处查看插件说明</a>

有任何疑问请发邮件到tanteng@gmail.com，将第一时间回复，谢谢！
