<?php
// Silence is golden.插件入口文件wechat-reward.php
