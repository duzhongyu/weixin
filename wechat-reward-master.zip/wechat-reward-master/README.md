# wechat-reward
微信打赏WordPress插件

这是一个微信打赏WordPress小插件，在文章末尾添加微信打赏功能，如果读者觉得这篇文章对他有用，可以用微信扫一扫打赏赞助。

插件页面：http://www.tantengvip.com/2015/11/wechat-rewrd-wordpress-plugin/
